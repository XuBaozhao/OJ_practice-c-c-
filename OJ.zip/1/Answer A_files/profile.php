document.write("&nbsp;<a href=./modifypage.php>ModifyUser</a>&nbsp;<a href='./userinfo.php?user=201501061010'><span id=red>201501061010</span></a>&nbsp;<a href=./logout.php>Logout</a>&nbsp;");
